export const httpURI = 'http://192.168.134.30:5000/api'
export const webSocketURI = 'ws://192.168.134.30:5000/'